import React from "react"
import Header from "./components/Header"
import Trip from "./components/Trip"
import Text from "./components/Text"
import TripsData from "./data"


export default function App(){
    
    const trips = TripsData.map(trip => {
        return (
            <Trip 
                title = {trip.title}
                location = {trip.location}
                googleMaps = {trip.googleMapsUrl}
                startDate = {trip.startDate}
                endDate = {trip.endDate}
                description = {trip.description}
                imageUrl = {trip.imageUrl}
            />
        )
    })
    
export default function RenderText(){
    
function render(texts) {
    let listItems = ""
    for (let i = 0; i < texts.length; i++) {
        listItems += `
            <li>
                    ${texts[i]}
                </a>
            </li>
        `
    }
    ulEl.innerHTML = listItems
}

}
  
      return (
        <main>
            <Header /> 
            <Text />
            <div className="trips">
            {trips}
            </div>
        </main>
      )
}