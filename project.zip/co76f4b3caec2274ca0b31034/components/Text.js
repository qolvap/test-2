import React from "react"

export default function Text(){
    return (
        <container>
             <textarea placeholder="What's happening?" id="text-input"></textarea>
             <button id="input-btn">SAVE TEXT</button>
             <button id="delete-btn">DELETE ALL</button>
             <ul id="ul-el"></ul>
        </container>       
    )
}