import React from "react"

export default function Header(){
    return (
        <header>
            <img src="images/globe.svg" />
            <h1>My Travel Blog.</h1>
        </header>       
    )
}
